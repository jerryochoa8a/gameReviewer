import React from 'react';
import { StyleSheet,Button, View, Text, Image } from 'react-native';
import Card from '../shared/card'

export default function ReviewDetails({ navigation }) {

    const pressHandler=()=>{
        navigation.goBack();
    }

  return (
    <View style={styles.container}>
      {/* <Text>ReviewDetails Screen</Text> */}
      <Card>
        <Text>{ navigation.getParam('title') }</Text>
        <Text>{ navigation.getParam('body') }</Text>
        <Text>{ navigation.getParam('rating') }</Text>

        <View style={styles.rating}>
          <Text>GameZone rating: </Text>
          <Image style={styles.image} source={require('../images/star.png')} />
        </View>
      </Card>
      
      {/* <View style={styles.btn}> */}
          {/* <Button color="#FFFFFF" title='back to home' onPress={pressHandler}/> */}
      {/* </View> */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 24,
  },
  btn: {
    backgroundColor: 'blue',
    height: 40
  },
  rating: {
    paddingTop: 10
  },
  image: {
    width: 20,
    height: 20,
  }
});