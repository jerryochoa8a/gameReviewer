import React, {useState} from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity,
  ImageBackground, Modal, Button, TouchableWithoutFeedback, Keyboard } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import Form from './form'
import Card from '../shared/card';

export default function Home({ navigation }) {

  const [modalOpen, setModalOpen] = useState(false); 

    const [reviews, setReviews] = useState([
        { title: 'zelda, Breath of Fresh Air', rating: 5, body: 'lorem isum', key: '1' },
        { title: 'Gotta Catch Them All', rating: 4, body: 'lorem isum', key: '2' },
        { title: 'Final Final fantasy', rating: 3, body: 'lorem isum', key: '3' },
    ])

    const addReview = (review) => {
      review.key = Math.random().toString();
      setReviews((currentReviews) => {
        return [review, ...currentReviews]
      });
      setModalOpen(false);
    }
    

  return (
    <>
    {/* <ImageBackground style={styles.backImg} source={require('../images/game-back.jpg')}> */}

    
    {/* // */}
    <Modal visible={modalOpen} animationType='slide'>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <View style={StyleSheet.modelCon}>
        <MaterialIcons
          name='close'
          size={27}
          style={ {...styles.openClose, ...styles.openClose2} } //how to add two styles
          onPress={()=> setModalOpen(false)}
        />
        <Form addReview={ addReview }/>
      </View>
      </TouchableWithoutFeedback>
    </Modal>
    {/* // */}
    
    <MaterialIcons
      name='add'
      size={27}
      style={ styles.openClose }
      onPress={()=> setModalOpen(true)}
    />

    <FlatList
        data={reviews}
        renderItem={({ item }) => (
            <TouchableOpacity onPress={() => navigation.navigate('ReviewDetails', item)}>
              <Card>
                <Text style={styles.text} >{item.title}</Text>
              </Card>
            </TouchableOpacity>

        )} 
    />
    {/* </ImageBackground> */}
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 24,
  },
  btn: {
      backgroundColor: 'blue',
      height: 40
  },
  text: {
      padding: 10
  },
  backImg: {
    width: 375,
    height: 1000,
  },
  openClose: {
    marginTop: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#f2f2f2',
    padding: 10,
    borderRadius: 10,
    alignSelf: 'center',
  },
  openClose2:{
    marginTop: 25,
    marginBottom: 0,
  },
});