import React, { useState } from 'react';
import { StyleSheet, View, Text, Button, TextInput } from 'react-native';
import { Formik } from 'formik';
import axios from 'axios';
import * as yup from 'yup';
import FlatButton from '../shared/button';

const ReviewSchema = yup.object({
    title: yup.string().required().min(4),
    body: yup.string().required().min(4),
    rating: yup.string().required().test('is-num-1-5', 'Rating must be a number 1-5', (val) => {
        return parseInt(val) < 6 && parseInt(val) > 0;
    })
})


export default function Form({ addReview }) {

    const [gameStopTitle, setGameStopTitle] = useState("");
    const [gameStopBody, setGameStopBody] = useState("");
    const [gameStopRating, setGameStopRating] = useState();


    return (
        <>
            <Formik
                initialValues={{ title: '', body: '', rating: '' }}
                validationSchema={ReviewSchema}
                onSubmit={handleOnSubmit}
                onSubmit={(values) => {
                    console.log(values);
                    addReview(values);
                }}
            >

                {(props) => (
                    <View>
                        <TextInput
                            style={styles.textBox}
                            placeholder='Title'
                            onChangeText={props.handleChange('title')}
                            value={props.values.title}
                            onBlur={props.handleBlur('title')}
                        />
                        <Text style={styles.errorText}>{props.touched.title && props.errors.title}</Text>

                        <TextInput
                            multiline minHeight={60}
                            style={styles.textBox}
                            placeholder='Body'
                            onChangeText={props.handleChange('body')}
                            value={props.values.body}
                            onBlur={props.handleBlur('body')}
                        />
                        <Text style={styles.errorText}>{props.touched.body && props.errors.body}</Text>

                        <TextInput
                            style={styles.textBox}
                            placeholder='Rating(1-5)'
                            onChangeText={props.handleChange('rating')}
                            value={props.values.rating}
                            keyboardType='numeric'
                            onBlur={props.handleBlur('rating')}
                        />
                        <Text style={styles.errorText}>{props.touched.rating && props.errors.rating}</Text>


                        <FlatButton text='submit' onPress={props.handleSubmit} />
                        {/* <View style={styles.btnCon}>
                <View style={styles.btn}>
                    <Button title='Submit' color='white' onPress={props.handleSubmit} />
                </View>
            </View> */}
                    </View>
                )}


            </Formik>

        </>
    );
}

const styles = StyleSheet.create({
    textBox: {
        borderWidth: 1,
        borderColor: '#ddd',
        padding: 10,
        fontSize: 18,
        borderRadius: 6,
        width: 340,
        alignSelf: 'center'
    },
    btn: {
        backgroundColor: '#800000',
        width: 340,
        height: 50,
        paddingTop: 5,
    },
    btnCon: {
        alignSelf: 'center',
        marginTop: 10
    },
    errorText: {
        color: 'red',
        marginLeft: 20,
        fontSize: 15
    }
});