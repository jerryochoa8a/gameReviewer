// npm install @react-navigation/native
// expo install react-native-gesture-handler react-native-reanimated react-native-screens react-native-safe-area-context @react-native-community/masked-view
// npm install react-navigation-stack
// npm install react-navigation
// npm install react-navigation-drawer
// npm install formik //for forms
// npm install yup //for vallidations
// npm install firebase
import React, { Component } from 'react';
import Home from './screens/home';
import Navigator from './routes/drawer';
import firebase from 'firebase';

export default function App() {

    return (
      <Navigator />
    );
  }

